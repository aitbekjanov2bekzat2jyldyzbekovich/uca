<template>
  <div>
    <header class="w-full h-20 bg-green-800 sticky top-0 shadow-lg z-20">
      <div class="container mx-auto px-4 h-full">
        <vHeader :width="width" />
      </div>
    </header>
    <slot />
  </div>
</template>

<script>
import vHeader from "@/components/v-header.vue";
export default {
  components: { vHeader },
  props: {
    width: Number,
  },
};
</script>
