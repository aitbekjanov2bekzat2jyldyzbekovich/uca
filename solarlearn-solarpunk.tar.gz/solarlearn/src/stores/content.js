import { defineStore } from "pinia";

export const useContentStore = defineStore("content", {
  state: () => ({
    width: 0,
    lending: {
      intro: {
        title: "Эко-курсы для будущего, в котором технологии работают вместе с природой",
        text: "Создавай и проходи курсы по чистой энергии, зелёным городам и устойчивому образу жизни. Цифровой формат экономит бумагу, время и снижает углеродный след.",
        date: "2026",
        adress: "https://solarpunk.example.com",
        backgraund: ""
      },
      aboutApp: {
        title: "Платформа, которая помогает людям и природе",
        text: "Вместо бумажных учебников и поездок на занятия — онлайн-курсы. Каждый пройденный курс снижает расход бумаги и транспортные выбросы. Вместе мы строим SolarPunk-будущее: красивое, справедливое и устойчивое."
      }
    },
    loader: false,
  }),
  actions: {
    windowSize(width) {
      this.width = width;
      window.addEventListener("resize", () => {
        this.width = window.innerWidth;
      });
    },
    modalActive() {
      alert("Скоро: создание эко-курса на SolarLearn");
    },
  },
});
