<template>
  <lendLayout :width="this.$contentStore.width">
    <div>
      <div
        class="w-full min-h-[70vh] bg-gradient-to-br from-green-700 via-yellow-400 to-emerald-600 relative py-24 flex items-center"
      >
        <div class="absolute inset-0 bg-black bg-opacity-30"></div>
        <div class="container relative mx-auto px-4">
          <intro :intro="this.$contentStore.lending.intro" />
        </div>
      </div>
      <div class="container relative mx-auto px-4 pb-20">
        <aboutApp
          :aboutApp="this.$contentStore.lending.aboutApp"
          :width="this.$contentStore.width"
        />
        <!-- Секция пользы для природы -->
        <div class="pt-20">
          <h3 class="sectionName">Польза для природы и людей</h3>
          <div class="bg-green-50 border border-green-200 p-8 rounded-xl mt-6 shadow-sm">
            <h4 class="text-xl font-bold text-green-800 mb-3">Примерный расчёт на 1 курс</h4>
            <p class="Ptext mb-4">10 занятий по 2 часа, группа из 20 человек:</p>
            <ul class="list-disc pl-6 space-y-2 Ptext">
              <li><strong>Бумага:</strong> ~60–100 кг (учебники + раздатка) → 0 кг онлайн</li>
              <li><strong>Поездки:</strong> ~600–800 км суммарно → 0 км</li>
              <li><strong>CO₂:</strong> ≈ 70–120 кг сэкономлено на группу</li>
              <li><strong>Время:</strong> экономия 2–4 часов на дорогу на человека</li>
            </ul>
            <p class="mt-4 text-sm text-green-700 font-medium">
              Формула: (км × 0.12 кг CO₂/км) + (кг бумаги × 0.8 кг CO₂/кг)
            </p>
          </div>
        </div>
      </div>
    </div>
  </lendLayout>
</template>
<script>
import intro from "@/components/intro.vue";
import aboutApp from "@/components/aboutApp.vue";
export default {
  components: {
    intro,
    aboutApp,
  },
  mounted() {
    this.$contentStore.windowSize(window.innerWidth);
  },
};
</script>
