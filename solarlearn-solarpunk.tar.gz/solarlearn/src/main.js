import "./assets/main.css";
import "aos/dist/aos.css";
import { createApp } from "vue";
import { createPinia } from "pinia";
import { useContentStore } from "./stores/content";
import App from "./App.vue";
import router from "./router";
import lendLayout from "./layouts/lendLayout.vue";
import btn from "./components/btn.vue";
import loader from "./components/loader.vue";
import accordion from "./components/accordion.vue";
import AOS from "aos";

const app = createApp(App);
app.use(createPinia());
app.use(router);
app.component("lendLayout", lendLayout);
app.component("btn", btn);
app.component("loader", loader);
app.component("accordion", accordion);
app.mount("#app");
app.config.globalProperties.$contentStore = useContentStore();

AOS.init();
