<template>
  <button class="p-2 rounded-md">
    <svg
      class="w-6 h-6 text-white dark:text-white"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      fill="currentColor"
      viewBox="0 0 17 14"
    >
      <path
        d="M16 2H1a1 1 0 0 1 0-2h15a1 1 0 1 1 0 2Zm0 6H1a1 1 0 0 1 0-2h15a1 1 0 1 1 0 2Zm0 6H1a1 1 0 0 1 0-2h15a1 1 0 0 1 0 2Z"
      ></path>
    </svg>
  </button>
</template>

<style lang="css" scoped>
button {
  transition: all 100ms ease-in;
}
button:active {
  background-color: rgba(0, 0, 0, 0.2);
}
</style>
