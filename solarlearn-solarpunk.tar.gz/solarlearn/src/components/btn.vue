<template>
  <button
    class="py-4 px-12 rounded-lg shadow-lg text-lg font-bold relative overflow-hidden    shadow-blue-800 "
  >
    {{ placeHolder }}
  </button>
</template>

<script>
export default {
  props: {
    placeHolder: String,
  },
};
</script>

<style lang="css" scoped>
button {
  transition: scale 400ms linear;
}
button:hover {
  scale: 1.1;
}
button::after {
  content: "";
  width: 100%;
  height: 100%;
  scale: 0;
  position: absolute;
  background-color: rgba(0, 0, 0, 0.2);
  top: 0;
  left: 0;
  transition: scale 100ms ease;
}
button:active::after {
  scale: 1;
}
</style>
