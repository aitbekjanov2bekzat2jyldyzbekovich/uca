<template></template>

<script>
export default {
  props: {
    curs: Array,
  },
  mounted() {

  },
};
</script>
