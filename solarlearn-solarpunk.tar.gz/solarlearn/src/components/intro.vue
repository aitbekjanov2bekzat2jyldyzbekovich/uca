<template>
  <div class="h-full w-full flex flex-col justify-center items-start gap-6 text-white">
    <div class="flex gap-2 flex-wrap">
      <span class="uppercase text-base font-bold text-yellow-200 tracking-widest">
        SolarPunk-платформа:
      </span>
      <a
        :href="intro.adress"
        target="_blank"
        class="text-base text-white underline hover:text-yellow-200"
      >
        {{ intro.adress }}
      </a>
    </div>
    <h1 class="font-bold text-white text-4xl md:text-5xl w-full md:w-4/5 leading-tight">
      {{ intro.title }}
    </h1>
    <div class="flex gap-2">
      <span class="text-base font-bold uppercase text-yellow-200">Запущено |</span>
      <span class="text-white">{{ intro.date }}</span>
    </div>
    <p class="text-white/90 text-lg w-full md:w-3/4">
      {{ intro.text }}
    </p>
    <btn
      @click="this.$contentStore.modalActive()"
      placeHolder="Создать эко-курс"
      class="bg-green-600 hover:bg-green-700 text-white px-8 py-3 font-semibold"
    />
  </div>
</template>

<script>
export default {
  props: {
    intro: Object,
  },
};
</script>
