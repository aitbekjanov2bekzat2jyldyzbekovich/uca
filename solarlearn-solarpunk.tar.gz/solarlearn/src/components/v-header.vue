<template>
  <div class="flex justify-between h-full items-center w-full">
    <div class="flex gap-2 items-center">
      <div class="logo w-12 h-12 md:w-14 md:h-14 bg-green-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
        ☀️
      </div>
      <h2 class="text-2xl md:text-3xl font-bold tracking-wider uppercase text-white">
        SolarLearn
      </h2>
    </div>

    <nav class="flex gap-6 md:gap-8 items-center" v-if="width > 560">
      <ul class="flex gap-6 md:gap-8">
        <li>
          <router-link to="/" class="headNavBarLink">Главная</router-link>
        </li>
        <li>
          <router-link to="/" class="headNavBarLink">Эко-курсы</router-link>
        </li>
        <li>
          <router-link to="/" class="headNavBarLink">Мои курсы</router-link>
        </li>
        <li>
          <span class="headNavBarLink cursor-pointer" @click="this.$contentStore.modalActive()">Поиск</span>
        </li>
      </ul>
      <btn
        placeHolder="Войти"
        class="bg-white text-green-700 hover:bg-green-50"
        @click="this.$contentStore.modalActive()"
      />
    </nav>
    <burgerMenu @click="this.$contentStore.modalActive()" v-else />
  </div>
</template>

<script>
import burgerMenu from "./burgerMenu.vue";
export default {
  props: {
    width: Number,
  },
  components: {
    burgerMenu,
  },
};
</script>

<style lang="css" scoped>
.headNavBarLink {
  cursor: pointer;
  color: white;
  font-size: 1rem;
  font-weight: 500;
  position: relative;
  transition: color 0.2s;
}
.headNavBarLink:hover {
  color: #fef08a;
}
.headNavBarLink::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: -2px;
  width: 0;
  height: 2px;
  background-color: #fef08a;
  transition: width 0.2s ease;
}
.headNavBarLink:hover::after {
  width: 100%;
}
</style>
