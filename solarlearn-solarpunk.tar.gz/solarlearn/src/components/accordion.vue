<template>
  <div class="w-full">
    <span @click="toggle" class="Ptext">{{ title }} </span>
    <span v-if="!isOpen" class="Ptext tracking-wider"> ...</span>
    <Transition>
      <span v-if="isOpen" class="Ptext">{{ content }}</span>
    </Transition>

    <div>
      <button @click="toggle" class="float-end">
        <span v-if="!isOpen" class="font-semibold text-[#16a34a]"
          >Подробнее</span
        >
        <span v-else class="font-semibold text-[#16a34a]">Свернуть</span>
      </button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    text: {
      type: String,
      required: true,
    },
    size: Number,
  },
  data() {
    return {
      isOpen: false,
    };
  },
  computed: {
    title() {
      let middle = Math.floor(this.text.length / this.size);
      return this.text.slice(0, middle);
    },
    content() {
      let middle = Math.floor(this.text.length / this.size);
      return this.text.slice(middle);
    },
  },
  methods: {
    toggle() {
      this.isOpen = !this.isOpen;
    },
  },
};
</script>

<style scoped>
/* Анимация аккордеона */
.v-enter-active,
.v-leave-active {
  transition: opacity 0.5s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}
</style>
