<template>
  <div class="pt-20 w-full flex flex-col gap-10">
    <h3 class="sectionName">О платформе:</h3>
    <div>
      <div class="w-full bg-green-50 p-8 md:p-16 rounded-xl flex flex-col gap-4 border border-green-100">
        <h2 class="head text-green-800">
          {{ aboutApp.title }}
        </h2>
        <p class="Ptext" v-if="width > 560">
          {{ aboutApp.text }}
        </p>
        <accordion v-else :text="aboutApp.text" :size="5" />

        <div class="flex flex-wrap gap-6 pt-6 justify-center items-center text-green-700">
          <div class="text-center">
            <div class="text-4xl">☀️</div>
            <p class="text-sm mt-1">Чистая энергия</p>
          </div>
          <div class="text-center">
            <div class="text-4xl">🌱</div>
            <p class="text-sm mt-1">Зелёные города</p>
          </div>
          <div class="text-center">
            <div class="text-4xl">📚</div>
            <p class="text-sm mt-1">Цифровое обучение</p>
          </div>
          <div class="text-center">
            <div class="text-4xl">🌍</div>
            <p class="text-sm mt-1">Забота о природе</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: { aboutApp: Object, width: Number },
};
</script>
