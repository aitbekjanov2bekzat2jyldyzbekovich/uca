# SolarLearn

Платформа для создания и прохождения курсов по чистой энергии, зелёным городам и устойчивому образу жизни. Цифровой формат снижает бумагу, поездки и углеродный след.

## Как проект связан с SolarPunk

SolarPunk — это будущее, где технологии и природа работают вместе, создавая красивый, устойчивый и справедливый мир. SolarLearn приближает это будущее уже сейчас: учит людей создавать и жить в таком мире через удобные онлайн-курсы, экономя ресурсы планеты и снижая углеродный след обучения.

---

## English

A platform for creating and taking courses on clean energy, green cities, and sustainable living. Digital learning reduces paper, travel, and carbon footprint.

### How it connects to SolarPunk

SolarPunk is a vision of the future where technology and nature work together to create a beautiful, sustainable, and equitable world. SolarLearn brings this closer today by educating people through convenient online courses while saving planetary resources.

## Setup

```sh
npm install
npm run dev
```

Стек: Vue 3 + Vite + Tailwind + Pinia.
